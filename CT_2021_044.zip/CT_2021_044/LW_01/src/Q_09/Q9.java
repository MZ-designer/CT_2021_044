package Q_09;

import java.util.Scanner;

public class Q9 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

        int length = input.length();
        System.out.println(length);
        System.out.println(input.charAt(0));
        System.out.println(input.charAt(length - 1));

        scanner.close();
    }
}
