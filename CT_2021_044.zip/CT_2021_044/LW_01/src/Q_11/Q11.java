package Q_11;

import java.util.Scanner;

public class Q11 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter your full name (First Middle Last): ");
        String firstName = scanner.next();
        String middleName = scanner.next();
        String lastName = scanner.next();

        String formattedName = lastName + ", " + firstName + " " + middleName.charAt(0) + ".";
        System.out.println(formattedName);

        scanner.close();
    }
}
