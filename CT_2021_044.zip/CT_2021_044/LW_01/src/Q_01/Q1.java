package Q01;

import javax.swing.*;

public class Q1 {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Welcome to Java");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
